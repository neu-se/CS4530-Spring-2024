/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

export type ChatMessage = {
    interactableID?: string;
    dateCreated: string;
    body: string;
    sid: string;
    author: string;
};

