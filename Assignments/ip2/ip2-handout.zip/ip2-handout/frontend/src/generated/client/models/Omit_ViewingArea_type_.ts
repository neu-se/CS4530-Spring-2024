/* istanbul ignore file */
/* tslint:disable */
/* eslint-disable */

import type { Pick_ViewingArea_Exclude_keyofViewingArea_type__ } from './Pick_ViewingArea_Exclude_keyofViewingArea_type__';

/**
 * Construct a type with the properties of T except for those in type K.
 */
export type Omit_ViewingArea_type_ = Pick_ViewingArea_Exclude_keyofViewingArea_type__;
