import axios from 'axios';
import { echo } from './echo';

// // in order to test this function, I want to mock axios.get, so that
// // we don't actually make the http call.
// export async function echo(str: string) : Promise<string> {
//     const res =
//         await axios.get(`https://httpbin.org/get?answer=${str}`)
//     return res.data.args.answer
// }

describe('tests for echo', () => {
  beforeEach(jest.resetAllMocks);

  // this runs the http call.
  test('echo should return its argument', async () => {
    expect(await echo('33')).toEqual('33');
  });

  // this passes
  test('just spying on a function runs the original', async () => {
    const spy1 = jest.spyOn(axios, 'get');
    const str = '43';
    const correctURL = `https://httpbin.org/get?answer=${str}`;
    expect(await echo(str)).toEqual(str);
    expect(spy1).toBeCalledWith(correctURL);
    expect(spy1).toBeCalledTimes(1);
  });

  test("mocking the http call doesn't actually do a live call", async () => {
    const spy1 = jest.spyOn(axios, 'get');

    // have the mock return this
    const mockAnswer = '777';
    const mockResponse = { data: { args: { answer: mockAnswer } } };
    spy1.mockResolvedValue(mockResponse); // don't run the original!

    const realInput = '43'; // put this in the URL
    const realQuery = `https://httpbin.org/get?answer=${realInput}`;

    // 'echo' takes the realInput, but returns the mockAnswer,
    // so the http call must not have taken place
    expect(await echo(realInput)).toEqual(mockAnswer);
    expect(spy1).toBeCalledWith(realQuery);
    expect(spy1).toBeCalledTimes(1);
  });
});
