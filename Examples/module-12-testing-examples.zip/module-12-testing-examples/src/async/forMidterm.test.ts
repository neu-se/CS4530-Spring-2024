import * as db from './client';
import * as remotes from './remoteService'
import axios from 'axios';
import { nanoid } from 'nanoid'

/** EXCERPT FROM SUT 
 * 
FROM client.ts:
export async function addStudent(studentName: string): Promise<{ studentID: number }> {
    return remotePost('/transcripts', { name: studentName });
}

FROM remoteService.ts
export async function remotePost<T>(path:string, data?:any) : Promise<T> {
    try {
      const response : AxiosResponse<T> = await axios.post(path, data);
      return (response.data);
    } catch (e) { throw new Error(e as string); }
  }

 */

/**
 * In the Module 02 TDD exercise, addStudent returned a number. However, these tests
 * are based on the Module 05 Async exercise, where addStudent returned a {studentID: number}
 * Look at the const declarations for id1, etc.
 */
describe('tests for midterm', () => {

    // this restores all functions that were mocked or spied
    // to their original definitions
    beforeEach(jest.restoreAllMocks)

  test('1. addStudent should add a student to the database (BOGUS)', async () => {
    const randomName = nanoid()
    const id1 : {studentID:number} = await db.addStudent(randomName);
    expect(db.getStudentIDs(randomName)).toEqual([id1.studentID])
  });

  test('2. addStudent should add a student to the database (OK)', async () => {
    const randomName = nanoid()
    const id1 : {studentID:number} = await db.addStudent(randomName);
    await expect(db.getStudentIDs(randomName)).resolves.toEqual([id1.studentID])
  });

  test('3. the db can have more than one student with the same name (WILL PASS BUT BOGUS)',  // BOGUS
    async () => {
      const id1 = await db.addStudent('blair');
      const id2 = await db.addStudent('blair');
      expect(id1.studentID).not.toEqual(id2.studentID)
    })

  test('4. A newly-added student should have an empty transcript (OK)',
    async () => {
      const id1 = await db.addStudent('blair');
      const retrievedTranscript = await db.getTranscript(id1.studentID)
      expect(retrievedTranscript.grades).toEqual([])
      expect(retrievedTranscript.student)
        .toEqual({
          studentID: id1.studentID, studentName: "blair"
        })
    });

  test('5. addStudent should call remotePost correctly (OK)', async () => {
    const spy1 = jest.spyOn(db, 'addStudent')
    const spy2 = jest.spyOn(remotes, 'remotePost').mockResolvedValue(undefined)
    const spy3 = jest.spyOn(axios, 'post')
    const randomName = nanoid()
    const id1: { studentID: number } = await db.addStudent(randomName);
    expect(spy1).toBeCalledWith(randomName)
    expect(spy2).toBeCalledWith('/transcripts', { name: randomName })
    expect(spy3).not.toHaveBeenCalled
  });

  test('6. addStudent should call axios.post correctly (OK)', async () => {
    const spy1 = jest.spyOn(db, 'addStudent')
    const spy2 = jest.spyOn(remotes, 'remotePost')
    const spy3 = jest.spyOn(axios, 'post').mockResolvedValue({ data: undefined })
    const randomName = nanoid()
    const id1: { studentID: number } = await db.addStudent(randomName);
    // await expect(db.getStudentIDs(randomName)).resolves.toEqual([id1.studentID])
    expect(spy1).toBeCalledWith(randomName)
    expect(spy2).toBeCalledWith('/transcripts', { name: randomName })
    expect(spy3).toBeCalledWith('/transcripts', { name: randomName })
  });

  test('7. remotePost should call axios.post correctly (WILL BE BOGUS AFTER WE REMOVE THE ASYNC) ', async () => {

    const spy1 = jest.spyOn(remotes, 'remotePost')
    const spy2 = jest.spyOn(axios, 'post').mockResolvedValue({ data: undefined })
    const randomName : string = nanoid()
    await remotes.remotePost('/transcripts', { name: randomName })   
    expect(spy1).toBeCalledWith(randomName)
    expect(spy1).toBeCalledWith('/transcripts', { name: randomName })
    expect(spy2).toBeCalledWith('/transcripts', { name: randomName })
    expect(spy2).resolves.toEqual({ data: undefined })

  })

  test('8. addStudent should return an unique ID for the new student (BOGUS)',  // BOGUS
    () => {
      const id1 = db.addStudent('blair');
      const id2 = db.addStudent('corey');
      const id3 = db.addStudent('delta');
      expect(id1).not.toEqual(id2)
      expect(id1).not.toEqual(id3)
      expect(id2).not.toEqual(id3)
    });

  test('9. addStudent should return an unique ID for the new student',
    async () => {
       
      const names = ['blair', 'corey', 'delta'];
      const [id1, id2, id3] = await Promise.all(names.map(someName => db.addStudent(someName)))
      expect(id1).not.toEqual(id2.studentID)
      expect(id1).not.toEqual(id3.studentID)
      expect(id2).not.toEqual(id3.studentID)
    });

  test('10. the db can have more than one student with the same name',
    async () => {
      const id1 = await db.addStudent('blair');
      const id2 = await db.addStudent('blair');
      expect(id1.studentID).not.toEqual(id2.studentID)
    })

})


  




