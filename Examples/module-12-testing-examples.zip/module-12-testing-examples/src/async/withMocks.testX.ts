import * as db from './client';
import * as remotes from './remoteService'
import axios from 'axios';
import { nanoid } from 'nanoid'

describe('with mocks', () => {

  /**
 * Note that db.addStudent returns something slightly different from 'number'
 * Look at the const declarations for id1, etc.
 */

  test('addStudent should add a student to the database - with await', async () => {
    const randomName = nanoid()
    const id1: { studentID: number } = await db.addStudent(randomName);
    await expect(db.getStudentIDs(randomName)).resolves.toEqual([id1.studentID])
  });

  /** SUT:
   * export async function addStudent(studentName: string): Promise<{ studentID: number }> {
      return remotePost('/transcripts', { name: studentName });
}
   */
  test('addStudent should call remotePost correctly', async () => {
    const spy1 = jest.spyOn(db, 'addStudent')
    const spy2 = jest.spyOn(remotes, 'remotePost').mockResolvedValue(undefined)
    const spy3 = jest.spyOn(axios, 'post')
    const randomName = nanoid()
    const id1: { studentID: number } = await db.addStudent(randomName);
    // await expect(db.getStudentIDs(randomName)).resolves.toEqual([id1.studentID])
    expect(spy1).toBeCalledWith(randomName)
    expect(spy2).toBeCalledWith('/transcripts', { name: randomName })
    expect(spy3).not.toHaveBeenCalled
  });

  test('call to addStudent calls axios.post correctly', async () => {
    // let's mock remotePost (but let it run)
    const spy1 = jest.spyOn(db, 'addStudent')
    const spy2 = jest.spyOn(remotes, 'remotePost')
    const spy3 = jest.spyOn(axios, 'post').mockResolvedValue({ data: undefined })
    const randomName = nanoid()
    const id1: { studentID: number } = await db.addStudent(randomName);
    // await expect(db.getStudentIDs(randomName)).resolves.toEqual([id1.studentID])
    expect(spy1).toBeCalledWith(randomName)
    expect(spy2).toBeCalledWith('/transcripts', { name: randomName })
    expect(spy3).toBeCalledWith('/transcripts', { name: randomName })
  });

  test('addStudent should return an unique ID for the new student-no await (should fail)',
    () => {
      // we'll just add 3 students and check to see that their IDs
      // are all different.
      const id1 = db.addStudent('blair');
      const id2 = db.addStudent('corey');
      const id3 = db.addStudent('delta');
      expect(id1).not.toEqual(id2)
      expect(id1).not.toEqual(id3)
      expect(id2).not.toEqual(id3)
    });

  test('addStudent should return an unique ID for the new student- with await and Promise.all',
    async () => {
      // we'll just add 3 students and check to see that their IDs
      // are all different.
      const names = ['blair', 'corey', 'delta'];
      const [id1, id2, id3] = await Promise.all(names.map(someName => db.addStudent(someName)))
      expect(id1).not.toEqual(id2.studentID)
      expect(id1).not.toEqual(id3.studentID)
      expect(id2).not.toEqual(id3.studentID)
    });

  test('the db can have more than one student with the same name',
    async () => {
      const id1 = await db.addStudent('blair');
      const id2 = await db.addStudent('blair');
      expect(id1.studentID).not.toEqual(id2.studentID)
    })

  test('A newly-added student should have an empty transcript',
    async () => {
      const id1 = await db.addStudent('blair');
      const retrievedTranscript = await db.getTranscript(id1.studentID)
      expect(retrievedTranscript.grades).toEqual([])
      expect(retrievedTranscript.student)
        .toEqual({
          studentID: id1.studentID, studentName: "blair"
        })
    });

  test('getTranscript should throw an error when given a bad ID - no await (should fail)',
    () => {
      const randomID = Math.random() * 10000
      expect(() => db.getTranscript(randomID)).toThrowError()
    });

  test('getTranscript should throw an error when given a bad ID - with awaits',
    async () => {
      const randomID = Math.random() * 10000
      async function getRandomTranscript() { await db.getTranscript(randomID) }
      expect(getRandomTranscript).rejects   // 'await expect' also works here.
    });

})




