export type ToDoItem = {
    title: string; 
    priority: string
    key: number;
  };