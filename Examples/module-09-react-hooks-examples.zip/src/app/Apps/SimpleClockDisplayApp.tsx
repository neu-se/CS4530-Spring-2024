import * as React from 'react';
import { useState } from 'react';
import {
  Box,
  Button,
  VStack,
} from '@chakra-ui/react'

import { ClockDisplay } from '../Components/SimpleClockDisplay'

function doNothing() { }

export default function App() {
  return (<VStack>
    <ClockDisplay key={1} name={'Clock A'} handleAdd={doNothing} handleDelete={doNothing}/>
    <ClockDisplay key={2} name={'Clock B'} handleAdd={doNothing} handleDelete={doNothing} />
    <ClockDisplay key={3} name={'Clock C'} handleAdd={doNothing} handleDelete={doNothing}/>
  </VStack>)
}