import { fstat } from "fs";

function f () {
    console.log("F1");
    setTimeout(() => {
        console.log("F2");      
    }, 0);
    console.log("F3")
}

console.log("M1")
f()
console.log("M2")

