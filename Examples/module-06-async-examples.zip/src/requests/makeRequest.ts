import axios from 'axios';

export default async function makeRequest(requestNumber:number) {
    console.log(`makeRequest is about to start request ${requestNumber}`);
    const response = await axios.get('https://rest-example.covey.town');
    console.log(`makeRequest reports that for request '${requestNumber}', server replied: `, response.data);
}