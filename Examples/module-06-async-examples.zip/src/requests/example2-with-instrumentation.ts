import makeRequest from './makeRequest';
import timeIt from './timeIt'

async function makeThreeSimpleRequests() {
    const p1 = makeRequest(1);
    console.log(`p1 = ${p1}`);
    const p2 = makeRequest(2);
    console.log(`p2 = ${p2}`);
    const p3 = makeRequest(3);
    console.log(`p3 = ${p3}`);
    console.log("Three requests made; main thread finishes")
}

timeIt("main thread", makeThreeSimpleRequests)