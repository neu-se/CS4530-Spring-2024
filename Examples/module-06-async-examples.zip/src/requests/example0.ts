import makeOneGetRequest from './makeRequest';

export default async function main() {
    console.log("Making one request");
    const p1 = makeOneGetRequest(1);
    console.log(`p1 = ${p1}`);
    await p1;   // try this with and without the await
    console.log("Main thread finishes");
}

main()

