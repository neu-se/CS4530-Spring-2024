import axios from 'axios';
import { promises as fsPromises } from 'fs';

function dataFileName(studentID:number):string {
    return `transcript-${studentID}.json`
}

// works on any array of summable things.
function sum(numbers:number[]):number {
    return numbers.reduce((runningTotal, val) => runningTotal + val, 0);
}

/** aynchronously retrieves student data,  */
async function asyncGetStudentData(studentID: number) {
    const returnValue = await axios.get(`https://rest-example.covey.town/transcripts/${studentID}`)
    return returnValue
}

/** create a promise that gets the student data, writes the file,
 *  and returns its size
 */
async function asyncProcessStudent(studentID: number) : Promise<number> {
    // wait to get the student data
    const response = await asyncGetStudentData(studentID)    
    // asynchronously write the file  
    await fsPromises.writeFile(
        dataFileName(studentID),        
        JSON.stringify(response.data))
    // last, extract its size
    const stats = await fsPromises.stat(dataFileName(studentID))
    const size : number = stats.size
    return size
}
  
async function runClientAsync(studentIDs:number[]) {
    console.log(`Generating Promises for ${studentIDs}`); 
    const studentPromises =  studentIDs.map(studentID => asyncProcessStudent(studentID)) ;  
    console.log('Promises Created!');
    console.log('Satisfying Promises Concurrently')
    const sizes = await Promise.all(studentPromises);  
    console.log(sizes)        
    const totalSize = sum(sizes)
    console.log(`Finished calculating size: ${totalSize}`);
    console.log('Done');
  }

/** run with good IDs only */
runClientAsync([411, 412, 423])

/** show both good and bad inputs */
async function driver () {
  // these are IDs that happen to be in the db as of 11/14/22
  await runClientAsync([411,412,423])
  // adding IDs that are not in the data base throws an error
  console.log('\n\ntrying list with some bad ids')
  runClientAsync([411,412,87065,423,23044])
}

// driver()
  