import makeOneGetRequest from '../requests/makeRequest'

/* run-to-completion semantics:

    JS uses "run-to-completion" semantics.  This means that once a computation starts, it runs continuously
    until it is either completed or suspended.

    A computation is suspended when it hits an 'await'.

    By contrast, Java uses interrupt-based semantics, in which control can 
    pass from one computation to another at any time.

    To see the difference, consider the example below:

*/ 



let x : number = 10

async function asyncDouble() {
    await makeOneGetRequest(1);   // start an asynchronous computation and wait for the result
    x = x * 2  // statement 1
}

async function asyncIncrementTwice() {
    await makeOneGetRequest(2);     // start an asynchronous computation and wait for the result
    x = x + 1;   // statement 2
    x = x + 1;   // statement 3
}

async function run() {
    await Promise.all([asyncDouble(), asyncIncrementTwice()])
    console.log(x)
}

run()


/* 
In the JS run-to-completion semantics, statement 3 is guaranteed to
run immediately after statement 2, so the only possible orders of execution
are:
1,2,3   (1 runs before 2 and 3, final value of x is 22)
2,3,1   (2 and 3 run before 1, final value of x is 24)


In an interrupt-based model, it is possible that statement 1 runs *BETWEEN*
statement 2 and statement 3, yielding the order of execution
2,1,3  (final value of x is 25).

Notice that there is still a data race between statement 1 and statements 2 and 3;
run-to-completion semantics does not eliminate data races entirely, but it 
makes them much rarer.
*/

/*
In run-to-completion semantics, it is up to the programmer to ensure that
no single computation runs too long and blocks other necessary computations.

This is called "cooperative multitasking"
*/


