// import { example } from "./asyncExample"

/** DOESN'T DO ANYTHING INTERESTING */

export async function example(n:number) {
    doThisNow(n);
    const p1 = somePromise(n);
    // console.log('p1 =', p1)
    console.log(`p1 = ${p1}`)
    const response = await p1
    doThisLater(n);
}

function doThisNow (n) {console.log("doThisNow", n)}

async function somePromise (n) {
    return setTimeout(() => console.log("somePromise", n), 1000)
    }

function doThisLater (n) {console.log("doThisLater", n)}

async function forkJoin() {
    console.log("forkJoin started")
    const promises = [example(1), example(2), example(3)]
    console.log(promises)
    await Promise.all(promises)
    console.log("forkJoin finished\n")
}

async function main() {
    forkJoin()
    console.log("main finished\n")
}

main()