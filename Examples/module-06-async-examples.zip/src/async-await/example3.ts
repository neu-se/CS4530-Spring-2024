import { example } from "./asyncExample";

async function main() {
    await example(1)
    await example(2)
    await example(3)
    console.log("main finished\n")
}

main()
console.log("example3 finished\n")