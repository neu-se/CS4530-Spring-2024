export async function example(n:number) {
    doThisNow(n);
    const p1 = somePromise(n);
    console.log('p1 =', p1)
    const response = await p1
    doThisLater(n);
}

function doThisNow (n) {console.log("doThisNow", n)}
async function somePromise (n) {return `somePromise ${n}`}
function doThisLater (n) {console.log("doThisLater", n)}