import { example } from "./asyncExample"

function main () {
    console.log("calling example(1)")
    example(1)
    console.log("returning to main")
    console.log("main finished\n")
}

main()



