import { SimpleClock } from './simpleClockUsingPull';
import IClock from "./IPullingClock";

export class SimpleClockFactory {
    public static createClock () : IClock {
        return new SimpleClock()
    }
}