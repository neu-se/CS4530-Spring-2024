export class Server {

    /** the total number of times the button (in any of the clients) has been pushed */
    private _nPushes = 0

    public get nPushes(): number { return this._nPushes }

    public newClient(): Client { 
        return new Client(() => this._nPushes++) 
    }
}

export class Client {

    private handlePush: () => void

    constructor (_handlePush: () => void) {
        this.handlePush = _handlePush
    }

    public buttonPush () { this.handlePush() }
}


