import { Server } from './handlerPassing'

describe('handler passing', () => {

    it('works', () => {

        const server = new Server()
        const client1    = server.newClient()
        const client2    = server.newClient()

        expect(server.nPushes).toBe(0)
        client1.buttonPush()
        expect(server.nPushes).toBe(1)
        client2.buttonPush()
        expect(server.nPushes).toBe(2)
        client1.buttonPush()
        expect(server.nPushes).toBe(3)
    })
})